This is a project for an App (website) that will allow prize awarding at small horticultural shows (etc) 

![This is a test of its build status from Jenkins](http://ons-ubuntu.cloudapp.net/jenkins/job/showmanager/badge/icon)

