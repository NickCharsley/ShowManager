<?php
/*
 * File ons_common.php
 * Created on Jun 1, 2006 by N.A.Charsley
 * email php@oldnicksoftware.co.uk
 *
 *
 * Copyright 2006 ONS
 *
 */
error_log("Enter ".__FILE__);

$GLOBALS['test']=true;
$GLOBALS['TESTMODE']=true;

include_once("../ons_common.php");

//************************************************
error_log("Exit ".__FILE__);
?>
