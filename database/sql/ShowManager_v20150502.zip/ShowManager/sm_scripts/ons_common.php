<?php
/*
 * File common.php 
 * 
 * Created on 03-Feb-2006 by N.A.Charsley
 * 
 * Copyright 2006 ONS
 *
 * 
 * @codeCoverageIgnore 
 */
 if (!defined("__COMMON__"))
 	include_once('../ons_common.php');
?>
